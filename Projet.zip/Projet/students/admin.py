from django.contrib import admin
from students.models import Etudiant

# Register your models here.
admin.site.register(Etudiant)
