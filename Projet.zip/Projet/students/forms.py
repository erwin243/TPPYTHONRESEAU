from django import forms
from students.models import Etudiant


class StudentForm(forms.ModelForm):
  class Meta:
    model = Etudiant
    fields = ['matricule', 'Prenom', 'nom', 'email', 'domaine', 'promotion']
    labels = {
      'matricule': 'Matricule',
      'Prenom': 'Prenom',
      'nom': 'Nom',
      'email': 'Email',
      'domaine': 'Domaine',
      'promotion': 'Promotion'
    }
    widgets = {
      'matricule': forms.TextInput(attrs={'class': 'form-control'}),
      'Prenom': forms.TextInput(attrs={'class': 'form-control'}),
      'nom': forms.TextInput(attrs={'class': 'form-control'}),
      'email': forms.EmailInput(attrs={'class': 'form-control'}),
      'domaine': forms.TextInput(attrs={'class': 'form-control'}),
      'promotion': forms.TextInput(attrs={'class': 'form-control'}),
    }
