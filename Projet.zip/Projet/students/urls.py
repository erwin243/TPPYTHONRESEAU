from django.urls import path
from . import views

urlpatterns = [
  path('', views.index, name='index'),
  path('<int:id>', views.AfficherEtudiant, name='AfficherEtudiant'),
  path('ajouter/', views.ajouter, name='ajouter'),
  path('editer/<int:id>/', views.editer, name='editer'),
  path('delete/<int:id>/', views.delete, name='delete'),
]
