from django.db import models


# Create your models here.
class Etudiant(models.Model):
  matricule = models.CharField(max_length=50)
  Prenom = models.CharField(max_length=50)
  nom = models.CharField(max_length=50)
  email = models.EmailField(max_length=100)
  domaine = models.CharField(max_length=50)
  promotion = models.CharField(max_length=50)

  def __str__(self):
    return f'Student: {self.Prenom} {self.nom}'