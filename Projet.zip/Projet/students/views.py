from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse

from students.models import Etudiant
from students.forms import StudentForm


# Create your views here.
def index(request):
  return render(request, 'students/index.html', {
    'liste_etudiants': Etudiant.objects.all()
  })


def AfficherEtudiant(request, id):
  return HttpResponseRedirect(reverse('index'))


def ajouter(request):
  if request.method == 'POST':
    form = StudentForm(request.POST)
    if form.is_valid():
      new_matricule = form.cleaned_data['matricule']
      new_prenom = form.cleaned_data['Prenom']
      new_nom = form.cleaned_data['nom']
      new_email = form.cleaned_data['email']
      new_domaine = form.cleaned_data['domaine']
      new_promotion = form.cleaned_data['promotion']

      new_student = Etudiant(
        matricule=new_matricule,
        Prenom=new_prenom,
        nom=new_nom,
        email=new_email,
        domaine=new_domaine,
        promotion=new_promotion
      )
      new_student.save()
      return render(request, 'students/ajouter.html', {
        'form': StudentForm(),
        'success': True
      })
  else:
    form = StudentForm()
  return render(request, 'students/ajouter.html', {
    'form': StudentForm()
  })


def editer(request, id):
  if request.method == 'POST':
    student = Etudiant.objects.get(pk=id)
    form = StudentForm(request.POST, instance=student)
    if form.is_valid():
      form.save()
      return render(request, 'students/editer.html', {
        'form': form,
        'success': True
      })
  else:
    student = Etudiant.objects.get(pk=id)
    form = StudentForm(instance=student)
  return render(request, 'students/editer.html', {
    'form': form
  })


def delete(request, id):
  if request.method == 'POST':
    student = Etudiant.objects.get(pk=id)
    student.delete()
  return HttpResponseRedirect(reverse('index'))