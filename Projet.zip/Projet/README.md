asgiref==3.5.2
Django==4.0.4
flake8==6.0.0
mccabe==0.7.0
pycodestyle==2.10.0
pyflakes==3.0.1
sqlparse==0.4.2
